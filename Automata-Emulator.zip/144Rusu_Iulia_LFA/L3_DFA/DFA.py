# refolosesc functia load_automata din laboratorul 1 pentru a incarca un automat finit determinist dintr-un fisier
def load_DFA_automata(filename):
    with open(filename, 'r') as file:
        lines = [line.strip() for line in file if line.strip() and not line.startswith('#')]
    
    section = None
    states = set()
    alphabet = set()
    start_state = None
    accept_states = set()
    transition = {}

    for line in lines:
        if line.startswith('['):
            section = line[1:-1]
            continue
        
        if section == 'States':
            parts = line.split(',')
            states.update(parts[0])
            if len(parts) > 1:
                for state in parts[1:]:
                    if state == 'S':
                        start_state = parts[0]
                    elif state == 'A':
                        accept_states.add(parts[0])

        elif section == 'Alphabet':
            alphabet.update(line.strip())  
        elif section == 'Transitions':
            parts = [p.strip() for p in line.split(',')]
            if len(parts) == 3:
                state, symbol, next_state = parts
                if state not in transition:
                    transition[state] = {}
                transition[state][symbol] = next_state

    return states, alphabet, start_state, accept_states, transition

# functia care emuleaza un DFA pe baza unui sir de intrare si a unui automat finit determinist(procesat anterior)
def dfa_emulator(input_string, automata):
    current_state = automata[2] # se incepe cu starea de start
    accept_states = automata[3] 
    transition_function = automata[4]
    for symbol in input_string: # se parcurge fiecare simbol din sirul de intrare
        if symbol not in transition_function[current_state]: # daca simbolul nu exista in tranzitiile curente, automatul respinge sirul
            return False
        current_state = transition_function[current_state][symbol] # se actualizeaza starea curenta in functie de simbolul citit si tranzitia corespunzatoare
    
    return current_state in accept_states # se returneaza True daca starea curenta face parte din setul starilor de accept

automata = load_DFA_automata('DFA.txt')
input_list = ['1001', '1100', '101', '11111', '00','0001011']
for input_string in input_list:
    if dfa_emulator(input_string, automata):
        print(f"{input_string} e acceptat de catre DFA.")
    else:
        print(f"{input_string} e respins de catre DFA.")