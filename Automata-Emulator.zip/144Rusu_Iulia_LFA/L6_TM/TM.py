# refolosesc functia load_automata din laboratorul 1 pentru a incarca o masina Turing dintr-un fisier
def load_Turing_machine(filename):
    with open(filename, 'r') as file:
        lines = [line.strip() for line in file if line.strip() and not line.startswith('#')]
    
        section = None
        states = set()
        alphabet = set()
        start_state = None
        accept_states = set()
        transition = {}

        for line in lines:
            if line.startswith('['):
                section = line[1:-1]
                continue

            if section == 'States':
                parts = line.split(',')
                states.update(parts[0])
                if len(parts) > 1:
                    for state in parts[1:]:
                        if state == 'S':
                            start_state = parts[0]
                        elif state == 'A':
                            accept_states.add(parts[0])
            elif section == 'Alphabet':
                alphabet.update(line)  
            elif section == 'Transitions':
                left, right = line.split('->')
                # aceeasi formatare ca la PDA, se impart partea stanga si cea dreapta in simboluri separate
                left_parts = [p.strip() for p in left.strip().split(',')]
                right_parts = [p.strip() for p in right.strip().split(',')]

                current_state, current_symbol = left_parts[0], left_parts[1] # starea curenta este primul element din partea stanga, apoi simbolul curent
                next_state, write_symbol, direction = right_parts[0], right_parts[1], right_parts[2] # starea urmatoare, simbolul de scriere si directia sunt elementele din partea dreapta
                if current_state not in transition:
                    transition[current_state] = {}
                transition[current_state][current_symbol] = (next_state, write_symbol, direction) # adaug tranzitia in dictionar, unde cheia este starea curenta si valoarea este un tuplu format din starea urmatoare, simbolul de scriere si directia
        
        return states, alphabet, start_state, accept_states, transition

# functie care emuleaza o masina Turing pe baza unui sir de intrare si a unei masini Turing (procesata anterior)
# in contextul dat, masina Turing va aduna doua numere unare separate de '+'
def turing_machine_emulator(input_string, automata):
    banda = list(input_string) # transform sirul de input intr-o banda, la care adaug un simbol de spatiu la final pentru a evita erori de indexare
    banda.append('')
    current_state = automata[2]
    accept_states = automata[3]
    transition_function = automata[4]
    pointer = 0 # un pointer pentru a urmari pozitia pe banda
    while True:
        if current_state in accept_states:
            result = ''.join(banda) # se returneaza rezultatul ca un sir de caractere daca starea curenta este una de acceptare
            return result
        if pointer < 0 or pointer >= len(banda): # verific daca pointerul este valid in raport cu banda
            return False
        if current_state not in transition_function:
            return False # daca starea curenta nu are tranzitii definite, se returneaza False
        current_symbol = banda[pointer] # simbolul curent de pe banda este cel de la pozitia pointer
        next_state, write_symbol, direction = transition_function[current_state].get(current_symbol, (None, None, None)) # daca nu exista tranzitie pentru simbolul curent, se returneaza None pentru toate cele trei valori
        banda[pointer] = write_symbol
        # decid cum ma deplasez pe banda in functie de directia specificata
        if direction == 'R':
            pointer += 1
        elif direction == 'L':
            pointer -= 1
        current_state = next_state

automata = load_Turing_machine('TM.txt')
input_list = ['1+1', '11+111', '111+1111', '11+111','10+11']
for input_string in input_list:
    result = turing_machine_emulator(input_string, automata)
    if result is not False:
        print(f"{input_string} a fost procesat de TM cu rezultatul: {result}.")
    else:
        print(f"{input_string} nu a fost acceptat de TM.")