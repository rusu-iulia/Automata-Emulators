# refolosesc functia load_automata din laboratorul 1 pentru a incarca un automat pushdown dintr-un fisier
def load_PDA_automata(filename):
    with open(filename, 'r',encoding='utf-8') as file: # din nou, folosesc encoding='utf-8' pentru a evita problemele cu caracterul epsilon
        lines = [line.strip() for line in file if line.strip() and not line.startswith('#')]
    
    section = None
    states = set()
    alphabet = set()
    start_state = None
    accept_states = set()
    stack_alphabet = set()
    transition = {}

    for line in lines:
        if line.startswith('['):
            section = line[1:-1]
            continue

        if section == 'States':
            parts = [p.strip() for p in line.split(',')]
            states.add(parts[0])
            if len(parts) > 1:
                if 'S' in parts[1:]:
                    start_state = parts[0]
                if 'A' in parts[1:]:
                    accept_states.add(parts[0])

        elif section == 'Alphabet':
            alphabet.add(line.strip())

        elif section == 'StackAlphabet':
            stack_alphabet.add(line.strip())
        # la aceste tranzitii am formatat diferit fata de NFA, deoarece aici avem o tranzitie care depinde de simbolul de intrare si de varful stivei, deci voi face split pe '->' pentru a separa partea stanga de partea dreapta
        elif section == 'Transitions':
            left, right = line.split('->') 
            left_parts = [p.strip() for p in left.strip().split(',')] # impart partea stanga si cea dreapta in simboluri separate
            right_parts = [p.strip() for p in right.strip().split(',')]

            from_state, input_symbol, stack_top = left_parts # starea curenta, simbolul de intrare si varful stivei se afla in partea stanga
            to_state, push_symbols = right_parts # starea urmatoare si simbolurile de push se afla in partea dreapta

            # cheia pentru tranzitie este un tuplu format din simbolul de intrare si varful stivei
            key = (input_symbol, stack_top)
            if from_state not in transition:
                transition[from_state] = {} # daca starea curenta nu exista in dictionar, se creeaza
            if key not in transition[from_state]:
                transition[from_state][key] = [] # daca cheia nu exista in dictionar, se creeaza o lista goala pentru a adauga tranzitiile

            push_list = list(push_symbols) if push_symbols != 'ε' else [] # daca simbolurile de push nu sunt epsilon, se transforma in lista, altfel se foloseste o lista goala
            transition[from_state][key].append((to_state, push_list)) # adaug tranzitia in dictionar, unde cheia este un tuplu format din simbolul de intrare si varful stivei, iar valoarea este o lista de tupluri formate din starea urmatoare si simbolurile de push

    return states, alphabet, start_state, accept_states, stack_alphabet, transition

# functie care emuleaza un automat pushdown pe baza unui sir de intrare si a unui automat pushdown (procesat anterior)
def pda_emulator(input_string, automata, stack_symbol="$"):
    parts = [(automata[2], input_string, [stack_symbol])] # lista de parti contine un tuplu format din starea curenta, sirul de intrare si cu simbolul de start al stivei

    while parts: # cat timp exista lista partilor nu e goala
        current_state, remaining_input, stack = parts.pop() # fac pop la ultima parte din lista, care contine starea curenta, sirul de intrare ramas si stiva curenta

        # se verifica daca starea curenta este o stare de acceptare si daca nu mai exista sir de intrare ramas pentru procesare
        if not remaining_input and current_state in automata[3]:
            return True
        # se initializeaza varful stivei cu ultimul element din stiva, daca exista, altfel il setez la None
        top = stack[-1] if stack else None
        # se parcurg toate simbolurile de intrare din inputul ramas, daca exista, si se verifica tranzitiile, inclusiv tranzitiile epsilon
        for symbol in ([remaining_input[0]] if remaining_input else []) + ['ε']:
            key = (symbol, top) # cheia pentru tranzitie este un tuplu format din simbolul de intrare si varful stivei
            for next_state, push_symbols in automata[5].get(current_state, {}).get(key, []): 
                new_stack = stack[:-1] if stack else [] #facem pop din stiva
                for s in reversed(push_symbols): # adaugam simbolurile de push in stiva, in ordine inversa
                    if s != 'ε': 
                        new_stack.append(s) # daca simbolul de push nu este epsilon, il adaug in stiva
                # adaugam urmatoarea stare, sirul de intrare ramas si noua stiva in lista de parti
                next_input = remaining_input[1:] if symbol !='ε' else remaining_input
                parts.append((next_state, next_input, new_stack))
    
    return False

automata = load_PDA_automata('pda.txt')
input_list = ["ab", "aabb", "aaabbb", "aab", "aaa", "bb"]
for input_string in input_list:
    if pda_emulator(input_string, automata):
        print(f"{input_string} e acceptat de catre PDA.")
    else:
        print(f"{input_string} e respins de catre PDA.")