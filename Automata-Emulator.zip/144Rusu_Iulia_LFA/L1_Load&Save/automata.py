# Laborator 1 - Load & Save Automata
# functie care incarca un automat finit dintr-un fisier
def load_automata(filename):
    with open(filename, 'r') as file:
        lines = [line.strip() for line in file if line.strip() and not line.startswith('#')]
        # se parcurge fiecare linie si se identifice sectiunile
        section = None
        states = set()
        alphabet = set()
        start_state = None
        accept_states = set()
        transition = {}

        for line in lines:
            if line.startswith('['): # s-a ajuns la o o noua sectiune
                section = line[1:-1] # se actualizeaza sectiunea curenta
                continue
            
            if section == 'States': # se proceseaza sectiunea de stari ale automatului
                parts = line.split(',') # parts va contine starea de pe linia curenta: (ex: q0, S) )
                states.update(parts[0]) # se adauga starea curenta(ex: q0, fara S/F) in multimea de stari
                if len(parts) > 1: # daca exista mai multe parti, se verifica daca este starea de start sau de acceptare
                    for state in parts[1:]:
                        if state == 'S':
                            start_state = parts[0]  # se seteaza starea de start, ea fiind unica
                        elif state == 'A':
                            accept_states.add(parts[0])  # se adauga starea de accept in multimea de stari de accept

            elif section == 'Alphabet':
                alphabet.update(line)  #adaug un simbol in alfabet, unde fiecare linie contine un singur simbol
            elif section == 'Transitions':
                parts = [p.strip() for p in line.split(',')] # se imparte linia in parti, pentru a obtine starea curenta, simbolul si starea urmatoare(ex: q0, 0, q1), fiind separate prin virgula
                if len(parts) == 3: # daca lungimea e diferita de 3, linia nu e valida, deci nu se proceseaza
                    state, symbol, next_state = parts 
                    if state not in transition:
                        transition[state] = {} #daca nu gaseste starea curenta in dictionarul de tranzitii, creez un dictionar gol pentru ea
                    transition[state][symbol] = next_state #se adauga tranzitia in dictionarul de tranzitii, unde cheia e starea curenta si valoarea e un dictionar cu simbolul si starea urmatoare

    return states, alphabet, start_state, accept_states, transition #se returneaza toate informatiile despre automatul finit sub forma de tuplu

# functie care salveaza un automat finit intr-un fisier
def save_automata(filename, automata):
    with open(filename, 'w') as file:
        states, alphabet, start_state, accept_states, transition = automata # se initializeaza variabilele automatului din tuplul oferit ca argument functiei

        file.write('[States]\n')
        for state in states:
            if state == start_state:
                file.write(f"{state}, S\n") # se scrie starea de start, marcata cu S
            elif state in accept_states:
                file.write(f"{state}, A\n") # se scrie starea de accept, marcata cu A
            else: 
                file.write(f"{state}\n") # se scrie o stare normala
        file.write('[End]\n')

        file.write('\n[Alphabet]\n')
        for symbol in alphabet:
            file.write(f"{symbol}\n") # se scrie pe rand fiecare simbol din alfabet
        file.write('[End]\n')

        file.write('\n[Transitions]\n')
        for state, transitions in transition.items(): # se parcurge dictionarul de tranzitii in functie de cheia stare
            for symbol, next_state in transitions.items(): # se parcurge fiecare tranzitie
                file.write(f"{state}, {symbol}, {next_state}\n")
        file.write('\n[End]\n')


automata = load_automata('load_automata.txt')
save_automata('save_automata.txt', automata)