# refolosesc functia load_automata din laboratorul 1 pentru a incarca un automat finit nedeterminist dintr-un fisier
def load_automata_NFA(filename): # am folosit encoding='utf-8' pentru a evita problemele cu caracterul epsilon (nu imi era procesat inainte)
    with open(filename, 'r',encoding='utf-8') as file:
        lines = [line.strip() for line in file if line.strip() and not line.startswith('#')]

    section = None
    states = set()
    alphabet = set()
    start_state = None
    accept_states = set()
    transition = {}

    for line in lines:
        if line.startswith('['):
            section = line[1:-1]
            continue

        if section == 'States':
            parts = line.split(',')
            states.update(parts[0])
            if len(parts) > 1:
                for state in parts[1:]:
                    if state == 'S':
                        start_state = parts[0]
                    elif state == 'A':
                        accept_states.add(parts[0])
        elif section == 'Alphabet':
            alphabet.update(line.strip())
        elif section == 'Transitions':
            parts = [p.strip() for p in line.split(',')]
            if len(parts) == 3:
                state, symbol, next_state = parts
                if state not in transition:
                    transition[state] = {}
                if symbol not in transition[state]:
                    transition[state][symbol] = set() # folosesc un set pentru a permite tranzitii multiple si il creez daca simbolul inca nu exista
                transition[state][symbol].add(next_state) # adaug urmatoarea stare in setul de tranzitii pentru starea curenta si simbolul curent
        
    return states, alphabet, start_state, accept_states, transition

# definesc functia epsilon_closure care calculeaza setul de stari care sunt accesibile dintr-un set de stari prin tranzitii epsilon
# o vom folosi pentru a calcula starile accesibile dintr-o stare curenta in timpul emulatiei NFA-ului
def epsilon_closure(states, transition_functions):
    closure = set(states) 
    stack = list(states) # folosesc o stiva pentru a stoca starea curenta si a explora tranzitiile epsilon
    
    while stack: # cat timp exista stari in stiva
        state = stack.pop() # fac pop la ultima stare din stiva
        for next_state in transition_functions.get(state, {}).get('ε', []): # se verifica daca exista tranzitii epsilon din starea curenta folosind functia get pentru a evita key errors
            if next_state not in closure: 
                closure.add(next_state) # daca exista o tranzitie epsilon catre o stare care nu este deja in closure, este adaugata
                stack.append(next_state) # se adauga starea curenta in stiva pentru a explora tranzitiile ei epsilon
    return closure # se returneaza closure-ul, adica setul de stari in care se poate ajunge din starea initiala prin tranzitii epsilon

# functie care emuleaza un NFA pe baza unui sir de intrare si a unui automat finit nedeterminist (procesat anterior)
def nfa_emulator(input_string, automata):
    current_states = {automata[2]} # se incepe cu starea de start, care e stocata intr-un dictionar pentru a permite multiple stari curente
    accept_states = automata[3]
    transition_function = automata[4]

    current_states = epsilon_closure(current_states, transition_function) # se calculeaza closure-ul, daca exista, pentru starea de start
    for symbol in input_string:
        next_states = set() # starile urmatoare vor fi stocate intr-un set pentru a evita duplicatele dar si pentru a permite sa fie mai multe
        for state in current_states:
            if state in transition_function and symbol in transition_function[state]: # se verifica daca exista tranzitii pentru starea curenta si simbolul curent, si apoi se adauga starile urmatoare in setul de tranzitii
                next_states.update(transition_function[state][symbol])
        current_states = epsilon_closure(next_states, transition_function) # se calculeaza closure-ul pentru starile urmatoare, daca exista, pentru a obtine starile accesibile dupa tranzitia curenta
    
    if not current_states:
        return False   # se returneaza False daca nu exista stari curente dupa procesarea intregului sir de intrare
    
    return any(state in accept_states for state in current_states) # se returneaza True daca cel putin una dintre starile curente este o stare de acceptare, altfel False

automata = load_automata_NFA('NFA.txt')
input_list = ['10', '000', '101', '11111', '001']
for input_string in input_list:
    if nfa_emulator(input_string, automata):
        print(f"{input_string} e acceptat de catre NFA.")
    else:
        print(f"{input_string} e respins de catre NFA.")